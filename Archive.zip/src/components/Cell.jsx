import React from "react";

const Cell = ({ id }) => {
  return <span className="cell"></span>;
};

export default Cell;
