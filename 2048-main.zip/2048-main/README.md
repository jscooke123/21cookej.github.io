# 2048 GAME 🕹

The famous 2048 game made in react, with a personal touch and animations

# Start the game
You can try the game from this link
   https://monicatvera.github.io/2048
     
## Built With 🛠️

* [VSCode](https://code.visualstudio.com/) - Code Editor
* [React](https://beta.reactjs.org/) - Javascript frontend library
* [SASS](https://sass-lang.com/) - CSS Preprocessor

## Authors 🖋

* **Mónica Ilenia Tardón Vera** [monicatvera](https://github.com/monicatvera)

